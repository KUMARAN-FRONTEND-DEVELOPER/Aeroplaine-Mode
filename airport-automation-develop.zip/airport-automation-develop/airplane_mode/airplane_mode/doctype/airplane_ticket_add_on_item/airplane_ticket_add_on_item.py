# Copyright (c) 2024, Ambibuzz and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class AirplaneTicketAddonItem(Document):
	pass
